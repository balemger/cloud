<?php

return [
    'adminEmail' => 'admin@example.com',
    'supportEmail' => 'noreply@bitspace.kz',
];
